VHDL-specific conversion tests
------------------------------

Requirements:
  * GHDL
  * py.test

