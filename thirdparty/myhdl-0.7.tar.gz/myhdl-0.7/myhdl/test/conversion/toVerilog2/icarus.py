from myhdl.conversion import verify, analyze

verify.simulator = analyze.simulator = "icarus"
