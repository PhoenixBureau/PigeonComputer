Verilog-specific conversion tests
---------------------------------

Requirements:
  * cver or icarus
  * py.test

See the Makefile - it contains targets per simulator. 
