Conversion tests that should work with both VHDL and Verilog
------------------------------------------------------------

Requirements:
  * cver, icarus, or GHDL
  * py.test

See the Makefile - it contains targets per simulator. 
