Requirements:
  * cver, icarus, or GHDL
  * py.test

See the Makefile - it contains targets per simulator. 
