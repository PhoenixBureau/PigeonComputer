from myhdl.conversion import verify

verify.simulator = "cver"
